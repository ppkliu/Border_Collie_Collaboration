extends SceneTree
# 由 export_godot_iso.py 產生。載入匯出的資源，核對設定與數量。

func _init() -> void:
	var manifest: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://manifest.json"))
	var ts: TileSet = load("res://iso_tileset.tres")
	var bad: Array[String] = []
	if ts.tile_shape != TileSet.TILE_SHAPE_ISOMETRIC or ts.tile_layout != TileSet.TILE_LAYOUT_DIAMOND_DOWN:
		bad.append("tile shape/layout")
	if ts.tile_size != Vector2i(64, 64 / 2):
		bad.append("tile_size %s" % ts.tile_size)
	var src: TileSetAtlasSource = ts.get_source(0)
	if src.get_tiles_count() != 16:
		bad.append("tiles %d" % src.get_tiles_count())
	for c in manifest["chars"]:
		var sf: SpriteFrames = load("res://chars/%s.tres" % c)
		for a in manifest["chars"][c]:
			if not sf.has_animation(a["name"]) or sf.get_frame_count(a["name"]) != int(a["n"]):
				bad.append("%s %s" % [c, a["name"]])
	var main: Node = (load("res://main.tscn") as PackedScene).instantiate()
	var ground: TileMapLayer = main.get_node("Ground")
	if ground.get_used_cells().size() != 24 * 24:
		bad.append("ground cells %d" % ground.get_used_cells().size())
	# 等距座標：Godot 的格子 (i, j) 中心在 ((i − j + 1) · U/2, (i + j + 1) · U/4)，
	# 比展示頁的投影多一個 U/2 的水平位移（展示頁以菱形頂點為原點）
	var p: Vector2 = ground.map_to_local(Vector2i(3, 1))
	if p != Vector2((3 - 1 + 1) * 64 / 2.0, (3 + 1 + 1) * 64 / 4.0):
		bad.append("map_to_local %s" % p)
	if main.get_node("Things").get_child_count() < 10:
		bad.append("things")
	var water: Polygon2D = main.get_node("Water")
	if water.polygon.size() != 4 or water.material == null:
		bad.append("water")
	var blocks := 0
	for c in main.get_node("Things").get_children():
		if String(c.name).begins_with("Block_"):
			blocks += 1
	if blocks == 0:
		bad.append("no terrace blocks")
	var strips := 0
	for c in main.get_node("Things").get_children():
		if String(c.name).begins_with("Obj_"):
			strips += 1
	if manifest["objects"].size() > 0 and strips == 0:
		bad.append("no object strips")
	main.free()
	if bad.is_empty():
		print("VERIFY_OK")
		quit()
	else:
		push_error("VERIFY_FAILED %s" % str(bad))
		quit(1)
