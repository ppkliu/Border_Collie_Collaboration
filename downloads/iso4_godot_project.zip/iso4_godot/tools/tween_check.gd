extends SceneTree
# 由 export_godot_iso.py 產生。把示範場景跑 2.5 秒，核對角色的打擊補間真的有發生：
# 有角色被打過、頓幀期間動畫暫停（speed_scale = 0）、被打後縮放與亮度會回到 1。

var _t := 0.0
var _main: Node
var _saw_freeze := false
var _saw_squash := false

func _initialize() -> void:
	_main = (load("res://main.tscn") as PackedScene).instantiate()
	root.add_child(_main)

func _process(delta: float) -> bool:
	_t += delta
	for c in _main.get_node("Things").get_children():
		if c is AnimatedSprite2D:
			if c.speed_scale == 0.0:
				_saw_freeze = true
			if abs(c.scale.x - 1.0) > 0.05 or abs(c.scale.y - 1.0) > 0.05:
				_saw_squash = true
	if _t < 2.5:
		return false
	var hits := 0
	var settled := true
	for c in _main.get_node("Things").get_children():
		if c is AnimatedSprite2D:
			hits += int(c.get("hit_count"))
	if hits > 0 and _saw_freeze and _saw_squash:
		print("TWEEN_OK hits=%d" % hits)
	else:
		push_error("TWEEN_FAILED hits=%d freeze=%s squash=%s" % [hits, _saw_freeze, _saw_squash])
	return true
