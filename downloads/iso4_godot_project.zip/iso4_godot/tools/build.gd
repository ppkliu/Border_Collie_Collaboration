extends SceneTree
# 由 export_godot_iso.py 產生。用 Godot 的 API 建立 TileSet、SpriteFrames 與示範場景後存檔。
#   godot --headless --path <專案> -s res://tools/build.gd

const U := 64
const MATS := ["grass", "dirt", "sand", "riverbed"]
const N := 24

func _init() -> void:
	var manifest: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://manifest.json"))
	# ---- TileSet ----
	var ts := TileSet.new()
	ts.tile_shape = TileSet.TILE_SHAPE_ISOMETRIC
	ts.tile_layout = TileSet.TILE_LAYOUT_DIAMOND_DOWN
	ts.tile_size = Vector2i(U, U / 2)
	var src := TileSetAtlasSource.new()
	src.texture = load("res://tiles/ground_atlas.png")
	src.texture_region_size = Vector2i(U, U / 2)
	for y in MATS.size():
		for x in 4:
			src.create_tile(Vector2i(x, y))
	ts.add_source(src, 0)
	_check(ResourceSaver.save(ts, "res://iso_tileset.tres"), "iso_tileset.tres")
	# ---- 角色 SpriteFrames ----
	for c in manifest["chars"]:
		var sf := SpriteFrames.new()
		sf.remove_animation("default")
		for a in manifest["chars"][c]:
			var tex: Texture2D = load("res://chars/" + a["file"])
			sf.add_animation(a["name"])
			sf.set_animation_speed(a["name"], a["fps"])
			sf.set_animation_loop(a["name"], true)
			for k in int(a["n"]):
				var at := AtlasTexture.new()
				at.atlas = tex
				at.region = Rect2(k * U, 0, U, U)
				sf.add_frame(a["name"], at)
		_check(ResourceSaver.save(sf, "res://chars/%s.tres" % c), c + ".tres")
	# ---- 示範場景 ----
	var root := Node2D.new()
	root.name = "Main"
	var ground := TileMapLayer.new()
	ground.name = "Ground"
	ground.tile_set = load("res://iso_tileset.tres")
	ground.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	root.add_child(ground)
	var noise := FastNoiseLite.new()
	noise.seed = 7
	noise.frequency = 0.12
	var land: Array[Vector2i] = []
	var raised := {}
	var himg := Image.create(N, N, false, Image.FORMAT_RF)      # 地形高度：河道低於 0，水面由著色器和水位比較
	for j in N:
		for i in N:
			var river: float = abs(i + 0.5 - (N * 0.5 + sin(j * 0.3) * 4.0))
			himg.set_pixel(i, j, Color(clampf((river - 1.9) / 2.5, -1.0, 1.0), 0, 0))
			var mat := 0
			if river < 1.6:
				mat = 3
			elif river < 2.4:
				mat = 2
			elif noise.get_noise_2d(i, j) > 0.25:
				mat = 1
			else:
				land.append(Vector2i(i, j))
				if river > 5.0 and noise.get_noise_2d(i * 0.6 + 40.0, j * 0.6) > 0.18:
					raised[Vector2i(i, j)] = true
			# 象限依格子座標的奇偶選，相鄰圖塊的紋理才連續
			ground.set_cell(Vector2i(i, j), 0, Vector2i((i & 1) + 2 * (j & 1), mat))
	# ---- 水面：一個蓋住整張地圖的菱形，著色器逐像素比較水位與內插後的高度 ----
	var htex := ImageTexture.create_from_image(himg)
	_check(ResourceSaver.save(htex, "res://height_map.tres"), "height_map.tres")
	var water := Polygon2D.new()
	water.name = "Water"
	var half := Vector2(U / 2.0, 0)
	water.polygon = PackedVector2Array([half, half + Vector2(N * U / 2.0, N * U / 4.0),
		half + Vector2(0, N * U / 2.0), half + Vector2(-N * U / 2.0, N * U / 4.0)])
	var wmat := ShaderMaterial.new()
	wmat.shader = load("res://shaders/iso_water.gdshader")
	wmat.set_shader_parameter("height_tex", load("res://height_map.tres"))
	wmat.set_shader_parameter("unit", float(U))
	wmat.set_shader_parameter("map_size", float(N))
	water.material = wmat
	root.add_child(water)
	var things := Node2D.new()
	things.name = "Things"
	things.y_sort_enabled = true
	root.add_child(things)
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	var ids: Array = manifest["props"]
	# ---- 台地：隆起一個方塊高的格子。方塊是一張貼圖（頂面＋兩個側面），排序位置在格子中心 ----
	for cell in raised:
		var b := Sprite2D.new()
		b.name = "Block_%d_%d" % [cell.x, cell.y]
		b.texture = load("res://blocks/block_grass_%d.png" % ((cell.x & 1) + 2 * (cell.y & 1)))
		b.centered = false
		b.offset = Vector2(-U / 2.0, -U / 4.0 - U / 2.0)
		b.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		b.position = ground.map_to_local(cell)
		things.add_child(b)
	# ---- 大型物件：找一塊夠大的平地；沿格線切成半格寬的直條，每條是一個 Sprite2D（region），
	# 位置放在那一條最靠近鏡頭的地面點，y 排序才會讓角色繞著物件走時前後正確 ----
	var used := {}
	var placed := 0
	var focus := Vector2.ZERO
	var landset := {}
	for cell in land:
		landset[cell] = true
	for oid in manifest["objects"]:
		var view: Dictionary = manifest["objects"][oid]["0"]
		var fw: int = int(view["footprint"][0])
		var fh: int = int(view["footprint"][1])
		var tex: Texture2D = load("res://objects/" + view["file"])
		for tries in 200:
			var o: Vector2i = land[rng.randi() % land.size()]
			var ok := true
			for b in range(-1, fh + 1):
				for a in range(-1, fw + 1):
					var c := o + Vector2i(a, b)
					if not landset.has(c) or raised.has(c) or used.has(c):
						ok = false
			if not ok:
				continue
			for b in fh:
				for a in fw:
					used[o + Vector2i(a, b)] = true
			var anchor := _iso(Vector2(o) + Vector2(fw, fh) / 2.0)
			for st in view["strips"]:
				var col: int = int(st["col"])
				var left: float = float(view["ax"]) - (fw + fh) / 4.0 * U
				var x0: int = 0 if col == 0 else int(round(left + col * U / 2.0))
				var x1: int = int(view["w"]) if col == view["strips"].size() - 1 else int(round(left + (col + 1) * U / 2.0))
				if x1 <= x0:
					continue
				var front := _iso(Vector2(o) + Vector2(float(st["front"][0]), float(st["front"][1])))
				var sp := Sprite2D.new()
				sp.name = "Obj_%s_%d_%d_%d" % [oid, o.x, o.y, col]
				sp.texture = tex
				sp.centered = false
				sp.region_enabled = true
				sp.region_rect = Rect2(x0, 0, x1 - x0, int(view["h"]))
				sp.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
				sp.position = Vector2(anchor.x, front.y - 0.5)
				sp.offset = Vector2(-float(view["ax"]) + x0, anchor.y - float(view["ay"]) - (front.y - 0.5))
				things.add_child(sp)
			if placed == 0:
				focus = anchor
			placed += 1
			break
	for cell in land:
		if used.has(cell) or rng.randf() > 0.22:
			continue
		var id: String = ids[rng.randi() % ids.size()]
		var tex: Texture2D = load("res://props/%s.png" % id)
		var s := Sprite2D.new()
		s.name = "%s_%d_%d" % [id, cell.x, cell.y]
		s.texture = tex
		s.centered = false
		s.offset = Vector2(-tex.get_width() / 2.0, -tex.get_height() + 1)   # 錨點＝貼圖底部中心
		s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		s.position = ground.map_to_local(cell)
		if raised.has(cell):                # 台地上的物件：往上抬一個方塊高，排序位置比方塊稍後
			s.position.y += 1.0
			s.offset.y -= U / 2.0 + 1.0
		if id.begins_with("tree") and things.get_child_count() % 3 == 0:     # 示範：每三棵樹有一棵積雪
			var wm := ShaderMaterial.new()
			wm.shader = load("res://shaders/weather_prop.gdshader")
			wm.set_shader_parameter("top_mask", load("res://props/%s.top.png" % id))
			wm.set_shader_parameter("snow", 0.8)
			s.material = wm
		things.add_child(s)
	# 示範：泥土圖塊上用遮罩 07 疊草地（材質交界）
	var demo := Sprite2D.new()
	demo.name = "DualMaskDemo"
	demo.texture = load("res://tiles/tile_dirt_0.png")
	demo.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	demo.position = ground.map_to_local(Vector2i(N / 2, N / 2)) + Vector2(0, -U * 2)
	var dm := ShaderMaterial.new()
	dm.shader = load("res://shaders/dual_mask.gdshader")
	dm.set_shader_parameter("upper_tex", load("res://tiles/tile_grass_0.png"))
	dm.set_shader_parameter("mask", load("res://masks/mask_dual_07.png"))
	demo.material = dm
	root.add_child(demo)
	var walker: Script = load("res://scripts/iso_character.gd")
	var n := 0
	for c in manifest["chars"]:
		for k in 3:
			var a := AnimatedSprite2D.new()
			a.name = "%s_%d" % [c, k]
			a.sprite_frames = load("res://chars/%s.tres" % c)
			a.centered = false
			a.offset = Vector2(-U / 2.0, -U * float(manifest["pivot_y"]))    # 腳底在格子底部中心
			a.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
			a.position = ground.map_to_local(land[(n * 37 + 5) % land.size()])
			a.set_script(walker)
			a.set("directions", int(manifest["directions"]))
			things.add_child(a)
			n += 1
	var cam := Camera2D.new()
	cam.name = "Camera"
	cam.position = focus if placed > 0 else ground.map_to_local(Vector2i(N / 2, N / 2))   # 鏡頭對準第一個大型物件
	root.add_child(cam)
	for node in _all(root):
		if node != root:
			node.owner = root
	var scene := PackedScene.new()
	_check(scene.pack(root), "pack main")
	_check(ResourceSaver.save(scene, "res://main.tscn"), "main.tscn")
	print("BUILD_OK tiles=%d props+chars=%d objects=%d" % [ground.get_used_cells().size(), things.get_child_count(), placed])
	root.free()
	quit()

# 格子座標（連續值，原點在格子的上角）→ TileMapLayer 的本地座標；格子 (i, j) 的中心是 _iso(i + 0.5, j + 0.5)
func _iso(p: Vector2) -> Vector2:
	return Vector2((p.x - p.y) * U / 2.0 + U / 2.0, (p.x + p.y) * U / 4.0)

func _all(n: Node) -> Array:
	var out: Array = [n]
	for c in n.get_children():
		out.append_array(_all(c))
	return out

func _check(err: int, what: String) -> void:
	if err != OK:
		push_error("FAILED %s: %d" % [what, err])
		quit(1)
