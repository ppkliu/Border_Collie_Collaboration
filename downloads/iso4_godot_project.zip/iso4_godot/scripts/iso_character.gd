extends AnimatedSprite2D
# 等距角色：依速度選動畫（idle／walk／run）與朝向。S、SE、E、NE、N 有貼圖，SW、W、NW 用 flip_h。
# directions = 4 時只沿等距的四個斜向（SE、SW、NE、NW）轉身。

@export var directions := 8
@export var walk_speed := 24.0
@export var run_speed := 60.0
@export var demo_hits := true          # 示範用：每隔幾秒自己被打一次
@export var turn_squash := true         # 轉向時水平壓扁 0.85 → 1（0.12 秒），蓋掉換方向那一幀的跳動
var _freeze := 0.0                       # 頓幀剩下的秒數：動畫與移動暫停
var hit_count := 0
var _next_hit := 0.0
var velocity := Vector2.ZERO
var _sector := 2            # 0=E，順時針每 45° 一格（螢幕 y 向下）
var _turn_hold := 0.0
var _wander := 0.0
# 扇區 → [貼圖方向, 是否鏡像]
const SECTORS := [["E", false], ["SE", false], ["S", false], ["SE", true], ["E", true], ["NE", true], ["N", false], ["NE", false]]

func _ready() -> void:
	_wander = randf() * TAU
	_next_hit = randf_range(0.2, 1.0)
	if directions == 4:
		_sector = 1

# 被打：頓幀 → 閃白 → 壓扁回彈 → 擊退。power 0–1，from 是出手者的位置。
# 全部用 Godot 的 Tween（create_tween）：閃白 quad／ease-out 0.12 秒、回彈 elastic／ease-out 0.28 秒、擊退 cubic／ease-out 0.2 秒，
# 都延遲到頓幀結束才開始。self_modulate 調到 3 倍亮度再淡回 1，就是白色的閃一下（深色描邊仍保留）。
func hit(from: Vector2, power: float = 1.0) -> void:
	var stop := 0.05 + 0.05 * power
	hit_count += 1
	_freeze = stop
	speed_scale = 0.0
	var resume := create_tween()
	resume.tween_interval(stop)
	resume.tween_callback(func(): speed_scale = 1.0)
	self_modulate = Color(3, 3, 3)
	create_tween().tween_property(self, "self_modulate", Color.WHITE, 0.12).set_delay(stop) 		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	scale = Vector2(1.0 + 0.25 * power, 1.0 - 0.22 * power)
	create_tween().tween_property(self, "scale", Vector2.ONE, 0.28).set_delay(stop) 		.set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)
	var away := (position - from).normalized() if position != from else Vector2.RIGHT
	create_tween().tween_property(self, "position", position + away * 10.0 * power, 0.2).set_delay(stop) 		.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)

func _process(delta: float) -> void:
	if demo_hits:
		_next_hit -= delta
		if _next_hit <= 0.0:
			_next_hit = randf_range(2.0, 4.0)
			hit(position + Vector2.from_angle(randf() * TAU) * 8.0, 1.0)
	if _freeze > 0.0:                    # 頓幀：不移動、不換動畫
		_freeze -= delta
		return
	# 示範用的隨機漫步；接進遊戲時改成由外部設定 velocity
	_wander += randf_range(-1.0, 1.0) * delta * 1.5
	velocity = Vector2(cos(_wander), sin(_wander) * 0.5) * walk_speed
	position += velocity * delta
	var speed := velocity.length()
	var state := "idle" if speed < walk_speed * 0.3 else ("walk" if speed < (walk_speed + run_speed) * 0.5 else "run")
	_turn_hold -= delta
	if speed > 1.0 and _turn_hold <= 0.0:
		# 偏離目前扇區中心超過門檻才轉，一次轉一格，轉完至少維持 0.4 秒
		var step := 2 if directions == 4 else 1
		var diff := wrapf(velocity.angle() - _sector * PI / 4.0, -PI, PI)
		if abs(diff) > (0.95 if directions == 4 else 0.56):
			_sector = posmod(_sector + (step if diff > 0.0 else -step), 8)
			_turn_hold = 0.4
			if turn_squash:
				create_tween().tween_property(self, "scale:x", 1.0, 0.12).from(0.85) 					.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	var s: Array = SECTORS[_sector]
	var anim := "%s_%s" % [state, s[0]]
	if not sprite_frames.has_animation(anim):
		anim = "%s_%s" % [state, "SE" if sprite_frames.has_animation(state + "_SE") else "S"]
	flip_h = s[1]
	if animation != anim:
		var f := frame_progress
		play(anim)
		frame_progress = f
